#!/bin/bash

# Cria ambiente virtual
python3 -m venv venv

# Ativa o ambiente
source venv/bin/activate

# Instala dependências
pip install -r requirements.txt

echo "Instalação concluída! Execute o script com:"
echo "source venv/bin/activate && python src/clp_firebase.py"