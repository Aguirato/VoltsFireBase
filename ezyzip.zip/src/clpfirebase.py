from pymodbus.client import ModbusTcpClient
from firebase_admin import credentials, db
import firebase_admin
import time
import logging
import os

logging.basicConfig(level=logging.INFO)

# Configurações via variáveis de ambiente (ajuste conforme sua necessidade)
FIREBASE_CREDENTIALS = os.getenv("FIREBASE_CREDENTIALS", "C:\Users\lusuq\OneDrive\Área de Trabalho\piui\VoltsFireBase\voltsteste-firebase-adminsdk-fbsvc-0790633160.json")
FIREBASE_DB_URL = os.getenv("FIREBASE_DB_URL", "https://console.firebase.google.com/project/voltsteste/database/voltsteste-default-rtdb/data/~2F")
CLP_IP = os.getenv("CLP_IP", "192.168.2.11.23")
MODBUS_PORT = int(os.getenv("MODBUS_PORT", "502"))
UPDATE_INTERVAL = float(os.getenv("UPDATE_INTERVAL", "0.5"))

REGISTERS = [
    {"name": "Tensão_Fase_A_V", "address": 0, "scale": 0.1},   # Registro 0, escala x0.1
    {"name": "Corrente_Fase_A_A", "address": 1, "scale": 0.01},
    {"name": "Frequência_Hz", "address": 2, "scale": 0.01},
    {"name": "Potência_Ativa_kW", "address": 3, "scale": 1},
    {"name": "Potência_Reativa_kVAR", "address": 4, "scale": 1},
    {"name": "Fator_Potência", "address": 5, "scale": 0.001},
    {"name": "THD_Tensão_%", "address": 6, "scale": 0.1},
    {"name": "THD_Corrente_%", "address": 7, "scale": 0.1},
    {"name": "Temperatura_°C", "address": 8, "scale": 0.1},
    {"name": "Estado_Relé", "address": 9, "scale": 1},         # Valor binário (0 ou 1)
    {"name": "Alarme_Sobrecarga", "address": 10, "scale": 1},
    {"name": "Energia_Total_kWh", "address": 11, "scale": 10},
]

def main():
    try:
        cred = credentials.Certificate(FIREBASE_CREDENTIALS)
        firebase_admin.initialize_app(cred, {'databaseURL': FIREBASE_DB_URL})
        logging.info("[Firebase] Conectado!")
    except Exception as e:
        logging.error(f"[Firebase] Erro: {e}")
        return

    client = ModbusTcpClient(CLP_IP, port=MODBUS_PORT)
    try:
        client.connect()
        logging.info(f"[Modbus] Conectado a {CLP_IP}:{MODBUS_PORT}")
    except Exception as e:
        logging.error(f"[Modbus] Erro: {e}")
        return

    try:
        while True:
            data = {"timestamp": time.time()}
            for reg in REGISTERS:
                try:
                    response = client.read_holding_registers(reg["address"], 1)
                    if not response.isError():
                        raw_value = response.registers[0]
                        scaled_value = raw_value * reg["scale"]
                        data[reg["name"]] = round(scaled_value, 3)
                    else:
                        data[reg["name"]] = None
                except Exception as e:
                    data[reg["name"]] = None

            try:
                ref = db.reference('/clp_data')
                ref.push(data)
                logging.info("[Firebase] Dados enviados!")
            except Exception as e:
                logging.error(f"[Firebase] Erro: {e}")

            time.sleep(UPDATE_INTERVAL)

    except KeyboardInterrupt:
        logging.info("Script interrompido.")
    finally:
        client.close()

if __name__ == "__main__":
    main()